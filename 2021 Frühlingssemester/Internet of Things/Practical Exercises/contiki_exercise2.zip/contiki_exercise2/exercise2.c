
/* Philipp Hurni, University of Bern, December 2013     */
/* Updated Eric Samikwa, University of Bern, March 2021     */

#include <stdio.h> /* For printf() */
#include <string.h>
#include "net/rime.h"
#include "dev/button-sensor.h" /* for the button sensor, sensor call: button_sensor */
#include "node-id.h"
#include "dev/leds.h"
#include "dev/sht11-sensor.h" /* for the temperature sensor, sensor call: sht11_sensor */
/*---------------------------------------------------------------------------*/
PROCESS(button_press_process, "Button Press Process");
/*---------------------------------------------------------------------------*/

void print_temperature_binary_to_float(uint16_t temp) {
	printf("temp: %d.%d\n", (temp / 10 - 396) / 10, (temp / 10 - 396) % 10);
}


PROCESS_THREAD(button_press_process, ev, data)
{
  PROCESS_BEGIN();

  SENSORS_ACTIVATE(button_sensor);

  PROCESS_WAIT_EVENT_UNTIL(ev == sensors_event && data == &button_sensor);

  leds_on(LEDS_BLUE);
  printf("button pressed\n");
  leds_off(LEDS_BLUE);

  SENSORS_DEACTIVATE(button_sensor);

  printf("Button Press Process EXITING!\n");

  PROCESS_END();
}


/*---------------------------------------------------------------------------*/
AUTOSTART_PROCESSES(&button_press_process);
/*---------------------------------------------------------------------------*/


/* Exercise 2a: compile and run the program. press the button (NOT reset button), observe what it does with
 * the serial interface
 */

/* Exercise 2b: alter the program such that whenever the button is pressed, the led
 * blinks and the string "button pressed" is printed
 */

/*
 * Exercise 2c (code to be uploaded in ILIAS): read out the temperature from the temperature
 * sensor when the button is pressed. print the temperature to the serial interface by
 * passing the value read from the sensor to print_temperature_binary_to_float().
 * Hint: the call sht11_sensor.value(SHT11_SENSOR_TEMP) returns the temperature value in binary
 * 
 * Note: you have atleast 1 node with environmental sensors. You
 * need to flash this node which has the sensors with your program here
 */



