#include "DGPExerciseToolbar.hh"

DGPExerciseToolbar::DGPExerciseToolbar(QWidget * parent)
        : QWidget(parent)
{
    setupUi(this);
}

