package exercise01;

public interface ICounter {
    public int getCount();

    public void setCount(int c);
}
