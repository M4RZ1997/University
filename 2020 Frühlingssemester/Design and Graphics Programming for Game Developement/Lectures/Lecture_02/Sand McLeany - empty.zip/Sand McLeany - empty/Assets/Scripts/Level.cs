﻿using UnityEngine;
using System;

[Serializable]
public class Level {
	public string name;
	public int scoreToWin;
	public int timeInSeconds;
}
