﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed = 5f;
    public float jumpValue = 8;
    private Rigidbody2D rigidbody;

    public Transform jumpCheckTranform;
    public float jumpCheckRadius = 0.3f;
    public LayerMask layerMask;

    void Start()
    {
        rigidbody = GetComponent<Rigidbody2D>();
    }
    
    void Update()
    {
        float horizontalValue = Input.GetAxis("Horizontal");
        Vector2 velocity = new Vector2(horizontalValue * speed, rigidbody.velocity.y);
        rigidbody.velocity = velocity;

        bool jumpIsDown = Input.GetButtonDown("Jump");
        bool isGrounded = Physics2D.OverlapCircle(jumpCheckTranform.position, jumpCheckRadius, layerMask);
        if (jumpIsDown && isGrounded)
        {
            rigidbody.AddForce(new Vector2(0, jumpValue), ForceMode2D.Impulse);
        }

        Vector2 scale = transform.localScale;
        if (velocity.x < 0)
        {
            scale.x = Mathf.Abs(scale.x);
        }else if (velocity.x > 0)
        {
            scale.x = -Mathf.Abs(scale.x);
        }
        transform.localScale = scale;
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Garbage")
        {
            collision.gameObject.SetActive(false);
        }
        Debug.Log(collision.gameObject.name);
        //Destroy(collision.gameObject);
    }
}
